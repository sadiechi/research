# the pygame I made imitates just the basic functions of the classic mobile jumpy games, where the player jumps on
# platforms to get as high up as possible.
# importing pygame and modules used:

import pygame
import random
import sys
from pygame.locals import *

# initiates pygame

pygame.init()

# window dimensions, setting up window

SCREEN_WIDTH = 400
SCREEN_HEIGHT = 700
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

# colour variables

WHITE = (255, 255, 255)
BLACK = (000, 000, 000)
PURPLE = (179, 138, 215)
PINK = (210, 156, 232)
BLUE = (109, 96, 180, 255)

# for pause screen fonts

pygame.font.get_fonts()

# game window caption

pygame.display.set_caption("Jumpy Kitty")

# variables (gravity and the number of platforms generated)

GRAVITY = 1
NUMBER_PLATFORMS = 10

# sets max FPS to 50

clock = pygame.time.Clock()
FPS = clock.tick(50)

# uploading images into pygame

player_image = pygame.image.load('Cat.png').convert_alpha()
bg = pygame.image.load('background.png').convert_alpha()
cloud = (pygame.image.load('cloud.png').convert_alpha())
sleepy = pygame.image.load('cat2.png').convert_alpha()
sleepy = pygame.transform.scale(sleepy, (300, 300))


# making a player class for my cat, a manual rect object

class Player:
    # next line creates object from class
    def __init__(self, x, y):
        self.image = player_image
        self.width = 50
        self.height = 40
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        # defines centre of player
        self.rect.center = (x, y)
        # velocity:
        self.vel_y = 0
        # returns a flipped image for the cat
        self.flip = False
        self.dx = 0
        self.dy = 0

    # defines movement function for cat:

    def move(self):
        # delta x and delta y variables (change in x and y)
        self.dx = 0
        self.dy = 0

        # function in pygame containing a list of keys, gives control of key inputs:
        key = pygame.key.get_pressed()
        # if key 'a' is pressed, player image is not flipped and goes left 20 pixels. etc.
        if key[pygame.K_a]:
            self.dx = -20
            self.flip = False
        if key[pygame.K_d]:
            self.dx = 20
            self.flip = True

        # adds gravity with velocity in the y direction (by adding velocity to change in y.)
        self.vel_y += GRAVITY
        self.dy += self.vel_y

        # This keeps cat from going off the screen:
        # e.g. if left side and dx together is less than 0, movement (dx) will be 0 minus left side. etc.

        if self.rect.left + self.dx < 0:
            self.dx = 0 - self.rect.left
        if self.rect.right + self.dx > SCREEN_WIDTH:
            self.dx = SCREEN_WIDTH - self.rect.right

        # This creates platform collision between platform rects and the player rect.

        for platform in platform_group:
            if platform.rect.colliderect(self.rect.x, self.rect.y + self.dy, self.width, self.height):
                if self.rect.bottom < platform.rect.centery:
                    if self.vel_y > 0:
                        self.rect.bottom = platform.rect.top
                        self.dy = 0
                        self.vel_y = -20

        # Collides cat with bottom of screen
        if self.rect.bottom + self.dy > SCREEN_HEIGHT:
            self.dy = 0
            # next line gives player an opposing negative velocity, making the cat jump constantly
            self.vel_y = -20

        self.rect.x += self.dx
        self.rect.y += self.dy

    def draw(self):
        screen.blit(pygame.transform.flip(self.image, self.flip, False), (self.rect.x - 47, self.rect.y - 58))
        # pygame.draw.rect(screen, WHITE, self.rect, 2) - this checks cat rect object
        # code on 118 draws movable rect function for cat.


# fonts = pygame.font.get_fonts()
# print(len(fonts))
# for f in fonts:
# print(f)

# setting up a platform class (as sprites)


class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, width):
        pygame.sprite.Sprite.__init__(self)
        self.width = width
        # adjusts cloud platforms
        self.image = pygame.transform.scale(cloud, (80, 50))
        # gets cloud rect object
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


# places cat somewhere on the screen, near to the bottom

cat = Player(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 100)

# keeps game loop running
running = True

# using pygame sprite groups to make platforms

all_sprites = pygame.sprite.Group()
platform_group = pygame.sprite.Group()
p1 = Platform(0, 0, 0)
all_sprites.add(p1)
platform_group.add(p1)

# generating random platforms using the random module in pygame

for p in range(NUMBER_PLATFORMS):
    # making random integer platforms, using random module in python (range is a series of random integers)
    # next line specifies range of random integers
    p_w = random.randint(60, 60)
    # limited by p_width (p_w):
    p_x = random.randint(0, SCREEN_WIDTH - p_w)
    # how far platforms are separated:
    p_y = p * random.randint(100, 120)
    # adds 'plat' to platform group made
    plat = Platform(p_x, p_y, p_w)
    platform_group.add(plat)

# drawing fonts for first screen


def draw_text(text, font1, colour, x, y):
    text = font1.render(text, True, colour)
    screen.blit(text, (x, y))


colour = WHITE

font1 = pygame.font.SysFont('couriernew', 25)


def draw_text2(text, font2, colour, x, y):
    text = font2.render(text, True, colour)
    screen.blit(text, (x, y))


font2 = pygame.font.SysFont('couriernew', 20)


def draw_text3(text, font3, purp, x, y):
    text = font3.render(text, True, purp)
    screen.blit(text, (x, y))


font3 = pygame.font.SysFont('couriernew', 20)

purp = PINK


# game loops


def main_screen():
    while True:

        screen.fill(BLUE)
        screen.blit(sleepy, (80, 80))

        draw_text("Welcome to Jumpy Kitty!", font1, colour, 30, 100)
        draw_text2("Press SPACE to start", font2, colour, 80, 130)
        draw_text3(" A and D controls", font3, purp, 90, 250)

        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_SPACE:
                    pause = True
                    if pause is True:
                        game()
        pygame.display.update()
        clock.tick(FPS)


def game():
    running = True
    while running:
        # needed for cat movement
        cat.move()
        # draws background
        screen.fill((50, 50, 50))
        screen.blit(bg, (0, 0))
        # draws sprites and updates pygame display
        cat.draw()
        platform_group.draw(screen)
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                    running = False
        pygame.display.update()
        clock.tick(FPS)


main_screen()
